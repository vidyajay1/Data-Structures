Vidya Jayaraman
vijayara
PA1
CS101

Makefile
ListClient.c
List.h
InsertSortLinked.c
List.c

This program is a linked list with different function implementations. It uses these function implementations to sort a list of numbers using Insertion Sort.