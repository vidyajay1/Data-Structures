//Vidya Jayaraman
// vijayara
// PA1
// This is List.c which has the different methods and functions for the doubly linked list.I implemented all the functions
//including the optional ones.
#include<stdio.h>

#include<stdlib.h>

#include "List.h"

#include <assert.h>

// Private inner NodeObj struct



typedef struct NodeObj

{
    
    int data;
    
    // pointer to the next node
    
    struct NodeObj* next;
    
    // pointer to the previous node
    
    struct NodeObj* prev;
    
}  NodeObj;





// private ListObj struct, constructor-destructor

typedef struct ListObj

{
    
    Node front;
    
    Node back;
    
    int length;
    
}  ListObj;

// Constructors/Destructors

// newNode()

Node newNode(int data){
    
    Node N = malloc(sizeof(NodeObj));
    
    N->data = data;
    
    N->prev = NULL;
    
    N->next = NULL;
    
    return(N);
    
}



// freeNode()

// frees heap memory

void freeNode(Node* pN) {
    
    if(pN != NULL && *pN != NULL) {
        
        free(*pN);
        
        *pN = NULL;
        
    }
    
}



// returns a List which points to a new empty list object

List newList(void){
    
    List L = malloc(sizeof(ListObj));
    
    L->front = L->back = NULL;
    
    L->length = 0;
    
    return(L);
    
}

// frees all heap memory associated with its List* argument,

// and sets *pL to NULL

void freeList(List* pL) {
    
    if(pL != NULL && *pL != NULL) {
        
        Node temp = (*pL)->front;
        
        while(temp != NULL) {
            
            Node current = temp;
            
            temp = temp->next;
            
            free(current);
            
        }
        
        
        
        //deallocates the memory
        
        free(*pL);
        
        *pL = NULL;
        
    }
    
}

// Returns the number of nodes in this List.

int length(List L) {
    
    if(L == NULL) {
        
        printf("List Error: calling length on NULL List reference");
        
        exit(1);
        
    }
    
    return(L->length);
    
}

// Returns the integer in the front Node.

// Precondition: L has at least one Node on it.

int frontValue(List L) {
    
    if(L == NULL){
        
        printf("List Error: calling frontValue() on NULL List reference\n");
        
        exit(1);
        
    }
    
    if(L->length==0 ){
        
        printf("List Error: calling frontValue() on empty List\n");
        
        exit(1);
        
    }
    
    return(L->front->data);
    
}

// Returns the integer in the back Node.

// Precondition: L has at least one Node on it.

int backValue(List L){
    
    if(L == NULL){
        
        printf("List Error: calling backValue on NULL List reference");
        
        exit(1);
        
    }
    
    if(L->length==0 ){
        
        printf("List Error: calling frontValue() on empty List\n");
        
        exit(1);
        
    }
    
    
    
    return(L->back->data);
    
}

// Returns the integer in Node N.

// Precondition: N is not NULL

int getValue(Node N){
    
    if(N == NULL){
        
        printf("List Error: calling getValue on NULL List reference");
        
        exit(1);
        
    }
    
    return(N->data);
    
}

// Returns 1 if if List A and List B are the same integer

// sequence, otherwise returns 0.

int equals(List A, List B){
    
    int equal = 0;
    
    Node R = NULL;
    
    Node S = NULL;
    
    if(A == NULL || B == NULL){
        
        printf("List Error: calling equals() on NULL List reference");
        
        exit(1);
        
    }
    
    equal = (A->length == B->length );
    
    R = A-> front;
    
    S = B-> front;
    
    while( equal && R != NULL){
        
        equal = (R->data==S->data );
        
        R = R->next;
        
        S = S->next;
        
    }
    
    return equal;
    
}

//Manipulation procedures



// Resets this List to the empty state.

void clear(List L){
    
    if(L == NULL){
        
        printf("List Error: calling clear on NULL List reference");
        
        exit(1);
        
    }
    
    Node current = L->front;
    
    Node remove = L->front;
    
    
    
    while(current != NULL){
        
        current = current->next;
        
        freeNode(&remove);
        
        remove = current;
        
    }
    
    L->front = NULL;
    
    L->back = NULL;
    
    L->length = 0;
    
}

// If List is non-empty, returns the front Node, without

// changing the List. Otherwise, does nothing.

Node getFront(List L){
    
    if (L == NULL){
        
        printf("List Error: calling getFront() on NULL List reference");
        
        exit(1);
        
    }
    
    if(L->length == 0 ){
        
        printf("List Error: calling getFront() on an empty List");
        
        exit(1);
        
    }
    
    else{  return(L->front);
        
    }
    
}

// If List is non-empty, returns the back Node, without

// changing the List. Otherwise, does nothing.

Node getBack(List L){
    
    if(L == NULL){
        
        printf("List Error: calling getBack() on NULL List reference");
        
        exit(1);
        
    }
    
    if( L->length == 0 ){
        
        printf("List Error: calling getBack() on NULL List reference");
        
        exit(1);
        
    }
    
    else{
        
        return(L->back);
        
    }
    
}

// Without changing the List that N is on, returns the

// Node that is previous to Node N on its List. If

// there is no previous Node, returns NULL.

Node getPrevNode(Node N){
    if(N == NULL){

        printf("List Error: calling getBack() on NULL List reference");

        exit(1);

    } 
    if(N->prev == NULL){
        
        return NULL;
        
    }else{
        
        
        
        return (N->prev);
        
    }
    
}

// Without changing the List that N is on, returns the

// Node that is next after Node N on its List. If

// there is no next Node, returns NULL.

Node getNextNode(Node N){
   if(N == NULL){

        printf("List Error: calling getBack() on NULL List reference");

        exit(1);

    }
     
    if(N->next == NULL){
        
        return NULL;
        
 }else{
    
    
        
        return(N->next);
        
    
    
}
}

// Inserts a new Node into List L before the front

// Node that has data as its value. If List is empty,

// makes that new Node the only Node on the list.

void prepend(List L, int data){
    
    Node N = malloc(sizeof(NodeObj));
    
    N->data = data;
    
    // Node A = malloc(sizeof(NodeObj));
    
    // A = L->front;
    
    if(L->front == NULL){
        
        L->front = N;
        
        L->length++;
        
        
        
    }
    
    else{
        
        L->front->prev = N;
        
        N->next =L->front;
        
        L->front = N;
        
        L->length++;
        
    }
    
    
    
}





// Inserts a new Node into List L after the back

// Node that has data as its value. If List is empty,

// makes that new Node the only Node on the list.

void append(List L, int data){
    
    Node N = malloc(sizeof(NodeObj));
    
    N->data = data;
    
    //Node A = malloc(sizeof(NodeObj));
    
    //A = L->back;
    
    if(L->front == NULL){
        
        L->front = N;
        
        L->back = N;
        
        //new node will be the last node
        
        //if linked list is empty, then make the new node as head
        
        L->length ++;
        
        return;
        
    }
    
    // while(A->next != NULL){
    
    //     A = A->next;  //to loop to last node
    
    // L->length++;
    
    // }
    
    // A->next = N;
    
    // N->prev = A;
    
    //make the size of list bigger
    
    //  L->length++;
    
    else{
        
        // A->next = N;
        
        L->back->next = N;
        
        N->prev = L->back;
        
        // N->prev = A;
        
        // A = N;
        
        L->back = N;
        
        L->length ++; //make the size of list bigger
        
        
        
    }
    
}

// Insert a new Node into Node N’s list

// before Node N that has data as its value.

// Assume that Node N is on List L. If Node N is

// the front of List L, then the new Node becomes the new

// front.

// Precondition: Node N is not NULL

void insertBefore(List L, Node N, int data){
    
    
    
    if(N == NULL) {
        
        printf("List Error: calling insertBefore() on NULL List Reference");
        
        exit(1);
        
    }
    
    if(L->length<=0){
        
        printf("List Error: calling insertAfter() on an empty List");
        
        exit(1);
        
    }
    
    
    
    Node new = malloc(sizeof(NodeObj));
    
    new->data = data;
    
    //Node A = malloc(sizeof(NodeObj));
    
    //A = L->back;
    
    if(L->front == N){
        
        L->front->prev = new;
        
        new->next = L->front;
        
        L->front = new;
        
        L->front->prev = NULL;
        
        L->length++;
        
        
        
    }else{
        
        
        
        //N->data is the cursor value
        
        
        
        new->next = N;
        
        new->prev = N->prev;
        
        //  if(N->next != NULL)
        
        //  N->prev->next = new;
        
        
        
        N->prev->next = new;
        
        N->prev = new;
        
        L->length++;
        
        
        
    }
    
}





// Insert a new Node into Node N’s list

// after Node N that has data as its value.

// Assume that Node N is on List L. If Node N is

// the back of List L, then the new Node becomes the new

// back.

// Precondition: Node N is not NULL

void insertAfter(List L, Node N, int data){
    
    Node new = malloc(sizeof(NodeObj));
    
    new->data = data;
    
    //Node A = malloc(sizeof(NodeObj));
    
    //A = L->front;
    
    if(N == NULL){
        
        printf("List Error: calling insertAfter() on a NULL List reference");
        
        exit(1);
        
    }
    
    if(L->length<=0){
        
        printf("List Error: calling insertAfter() on an empty List");
        
        exit(1);
        
    }
    
    
    
    if(L->back == N ){
        
        L->back->next = new;
        
        new->prev = L->back;
        
        L->back = new;
        
        L->back->next = NULL;
        
        L->length++;
        
    }
    
    else{
        
        new->prev = N;
        
        new->next = N->next;
        
        
        
        N->next->prev = new;
        
        N->next = new;
        
        L->length++;
        
    }
    
}






           
     

// Deletes the front Node in List L.

// Precondition: L has at least one Node on it.

void deleteFront(List L){
    
    if(L == NULL){
        
        printf("List Error: calling frontValue() on NULL List reference\n");
        
        exit(1);
        
    }
    
    if(L->length == 0 ){
        
        printf("List Error: calling frontValue() on empty List\n");
        
        exit(1);
        
    }
    
    
    
    
    
    Node N = malloc(sizeof(NodeObj));
    
    N = L->front;
    
    if(L->length > 1){
        
        L->front = L->front->next;
        
        L->front->prev = NULL;
        
        L->length --;
        
        freeNode(&N);
        
    }
    
    else{
        
        L->front = L->back = NULL;
        
        L->length --;
        
        freeNode(&N);
        
        
        
    }
    
    // Deletes the back Node in List L.
    
    // Precondition: L has at least one Node on it.
    
}

void deleteBack(List L) {
    
    if(L == NULL){
        
        printf("List Error: calling frontValue() on NULL List reference\n");
        
        exit(1);
        
    }
    
    if(L->length == 0 ){
        
        printf("List Error: calling frontValue() on empty List\n");
        
        exit(1);
        
    }
    
    Node N = malloc(sizeof(NodeObj));
    
    N = L->back;
    
    if(L->length > 1){
        
        L->back = L->back->prev;
        
        L->back->next = NULL;
        
        L->length --;
        
        freeNode(&N);
        
    }
    
    else {
        
        L->back = L->front = NULL;
        
        L->length--;
        
        freeNode(&N);
        
        
        
    }
    
}



// Prints the values in List L from front to back

// to the file pointed to by out, formatted as a

// space-separated string.

// For those familiar with Java, this is similar

// to toString()in Java.

void printList(FILE* out, List L){
    
    Node N = NULL;
    
    if(L == NULL){
        
        printf("List Error: calling printList() on NULL List reference");
        
        exit(1);
        
    }
    
    for(N = L->front; N != NULL; N = N->next){
        
        fprintf(out, "%d ", N->data);
        
    }
    
    printf("\n");
    
}

void deleteNode(List L, Node N){
    
    if(N == NULL){
        
        printf("List Error: calling frontValue() on NULL List reference\n");
        
        exit(1);
        
    }
    
    if(L->length == 0){
        
        printf("List Error: calling DeList on an empty List\n");
        
        exit(1);
        
    }
    
    
    
    if(N == L->front){
        
        deleteFront(L);
        
    }
    
    else if(N == L->back) {
        
        deleteBack(L);
        
    }
    
    else{
        
        N->prev->next = N->next;
        
        N->next->prev = N->prev;
        
        freeNode(&N);
        
        L->length--;
        
        
        
    }
    
}

void attachNodeBetween(List L, Node N, Node N1, Node N2){
    
    // This operation is optional.
    
    // Attaches Node N between Nodes N1 and N2. Makes N1's
    
    // next Node be N, and N's previous Node be N1. Makes
    
    // N2's previous Node be N, and N's next Node be N2.
    
    //
    
    // Special cases:
    
    //
    
    // If N1 is NULL and N2 is the front of List L, makes N
    
    // the front of List L, which should have a NULL
    
    // previous Node, and whose next Node should be N2.
    
    //
    
    // If N1 is the back of List L and N2 is NULL, makes N
    
    // the back of List L, which should have a NULL next
    
    // Node, and whose previous Node should be N1.
    
    //
    
    // Preconditions: N1 and N2 are adjacent nodes on List
    
    // L, with N2 being N1's next node and N1's being N2's
    
    // previous node. If N1 is NULL, then N2 is the front of
    
    // list L. If N2 is NULL, then N1 is the back of List L.
    
    if(N1 == NULL && N2 == L->front){
        
        N = L->front;
        
        N->prev = NULL;
        
        N->next = N2;
        
    }
    
    else if(N1 == L->back && N2 == NULL) {
        
        N = L->back;
        
        N->next = NULL;
        
        N->prev = N1;
        
    }
    
    else {
        
        N1->next = N;
        
        N->prev = N1;
        
        N->next = N2;
        
        N2->prev = N;
        
        
        
    }
    
    L->length++;
    
}



void detachNode(List L, Node N){ // This operation is optional.
    
    // Removes N from List L by making the Node before
    
    // Node N link to the Node that’s after Node N as its
    
    // next Node, and making the Node after Node N link to
    
    // the Node that’s before Node N as its previous Node.
    
    //
    
    // After detachNode, Node N should have NULL as both its
    
    // next and previous Nodes.
    
    //
    
    // Special cases:
    
    //
    
    // If Node N is the front the List L, then the Node after
    
    // Node N becomes the front of List L, which should have
    
    // a NULL previous Node.
    
    //
    
    // If Node N is the back of List L, then the Node before
    
    // Node N becomes the back of List L, which should have
    
    // a NULL next Node.
    
    //
    
    // Precondition: N is not NULL and N is a Node on List L.
    
    if (N == L->front){
        
        L->front = L->front->next;
        
        L->front->prev = NULL;
        
        N = NULL;
        
        //freeNode(&N);
        
    }
    
    else if (N == L->back){
        
        L->back = L->back->prev;
        
        L->back->next = NULL;
        
        N  = NULL;
        
        //freeNode(&N);
        
        
        
    }
    
    else{
        
        N->prev->next = N->next;
        
        N->next->prev = N->prev;
        
        N  = NULL;
        
        //freeNode(&N);
        
        
        
        
        
    }
    
    L->length--;
    
}
