//-----------------------------------------------------------------------------
// Vidya Jayaraman
//vijayara
// PA1
// This is the file input-output commands and text processing using the
// string functions strtok and strcat.The Insertion Sort method is in this file which
// is supposed to sort the numbers. 
//-----------------------------------------------------------------------------

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "List.h"
#define MAX_LEN 160

int main(int argc, char * argv[]){
   
   FILE *in, *out;
   char line[MAX_LEN];
   char* token;

   // check command line for correct number of arguments
   if( argc != 3 ){
      printf("Usage: %s <input file> <output file>\n", argv[0]);
      exit(1);
   }

   // open files for reading and writing 
   in = fopen(argv[0], "r");
   out = fopen(argv[1], "w");
   if( in==NULL ){
      printf("Unable to open file %s for reading\n", argv[1]);
      exit(1);
   }
   if( out==NULL ){
      printf("Unable to open file %s for writing\n", argv[2]);
      exit(1);
   }

   /* read each line of input file, then count and print tokens */
   while( fgets(line, MAX_LEN, in) != NULL)  {
      token = strtok(line, " \n");
List insert = newList();    
  while( token!=NULL ){
         int value = atoi(token);
         append(insert, value);
         token = strtok(NULL, " \n");
    
      }
     //printList(out, insert);
     //freeList(&insert);
     printList(out, insert);
     void InsertionSort(List insert);
     printList(out, insert);
    }
/* close files */
   fclose(in);
   fclose(out);

   return(0);
}
void InsertionSort(List L){
  Node key = getFront(L);
//  Node new = malloc(sizeof(Node));
  for (int j = 2; j <= length(L); j++){
 //key is for A[j]
  key = getNextNode(key);
 //current is for A[i] 
Node current = getPrevNode(key);
  int i = j-1;
  while(i > 0  && current > key){
  Node next = current;
  Node prev = key;
  detachNode(L, next);
  detachNode(L, prev);
  attachNodeBetween(L, prev, getPrevNode(next),getNextNode(next));
  attachNodeBetween(L, next, getPrevNode(prev), getNextNode(prev)); 

 // deleteNode(L, key);
//  current = getNextNode(current);
  // new = getPrevNode(current);
 // insertBefore(L, new, i);
//  new = getPrevNode(current);
}
key = getNextNode(current);
 }
   }


