// Vidya Jayaraman
// vijayara
// PA3
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Digraph.h"

struct DigraphObj {
    List *adjacency; //array of List: contains neighbors for a particular vertex
    //(depending on the jth element
    int numVertices; //number of vertices in Graph
    int numEdges; //number of edges in graph (size of graph)
    int *marks; //UNVISITED, INPROGRESS, ALLDONE
    //  List *n;
    int* parent;
    int* distance;
    int* new;
    
}
DigraphObj;


// Returns a Graph that points to a newly created GraphObj representing a graph which has
// n vertices and no edges.


Digraph newDigraph(int numVertices){
    Digraph graph = malloc(sizeof(struct DigraphObj));
    //const size_t size = sizeof(struct GraphObj);
    //Digraph graph = (struct DigraphObj*) malloc(size);
    graph->marks = malloc(sizeof(int)* (numVertices +1));
    graph->adjacency = malloc(sizeof(List)*(numVertices + 1));
    //graph->n = malloc(sizeof(List)*(numVertices + 1));
    graph->parent = malloc(sizeof(List)*(numVertices + 1));
    graph->distance = malloc(sizeof(List)*(numVertices + 1));
//    graph->new = malloc(sizeof(List)*(numVertices + 1));
    //G->time = 0;
    
    //  graph->adjacency = calloc(n+1, sizeof(List));
    //graph->marks = calloc(n+1, sizeof(int));
    graph->numVertices = numVertices;
    graph->numEdges = 0;
    int j;
    for(j = 0; j<(numVertices+1); j++) {
        graph->adjacency[j] = newList();
        graph->marks[j] = UNVISITED; //2 for unvisited
        // graph->n[j] = newList();
        graph->parent[j] = NIL;
        graph->distance[j] = INF;
  //      graph->new[j] = NIL; 
    }
    
    return graph;
}



// Frees all dynamic memory associated with its Graph* argument, and sets
// *pG to NULL.


void freeDigraph(Digraph *pG) {
    Digraph graph = *pG;
    
    if(pG != NULL && *pG != NULL){
        int j = 0;
        
        //printf("Hi");
        for(j = 0; j< getOrder(graph); j++){
            // printf("%d\n", length(graph->adjacency[j]));
            //   free(graph->adjacency[j]);
            
            freeList(&(*pG)->adjacency[j]);
            // free((graph)->adjacency[j]);
            // free(&(graph)->marks[j]);
        }
    //    free(graph->new);
        free(graph->parent);
        free(graph->distance);
        //        free(graph->adjacency);
        free(graph->marks);
        graph->adjacency = NULL;
        graph->marks = NULL;
        free(graph);
        *pG = NULL;
        pG = NULL;
    }
}

// Returns the order of G, the number of vertices in G.
int getOrder(Digraph G){
    if(G == NULL){
        printf("Graph Error: calling getOrder() on NULL Graph reference\n");
        exit(1);
    }
    // fprintf(out,"%d", G->numVertices);
    return G->numVertices;
    //  printf("%d",G->numVertices);
    
}

int getSize(Digraph G){
    // Returns the size of G, the number of edges in G.
    if(G == NULL){
        printf("Graph Error: calling getSize() on NULL Graph reference\n");
        exit(1);
    }
    return G->numEdges;
}
/*
 int getParent(Graph G, int u)
 {
 if (G == NULL)
 {
 printf("Graph error: cannot getParent() on NULL Graph reference\n");
 exit(1);
 }
 if (!(1 <= u && u <= getOrder(G)))
 {
 printf("Graph error: cannot getParent() if u is out of bounds\n");
 exit(1);
 }
 return G->parent[u];
 }
 int getDistance(Graph G, int u)
 {
 //printf("in getDist: G->distance[u] is: %d\n", G->distance[u]);
 if (G == NULL)
 {
 printf("Graph error: cannot getDist() on NULL Graph reference\n");
 exit(1);
 }
 if (!(1 <= u && u <= getOrder(G)))
 {
 printf("Graph error: cannot getDist() if u is out of bounds\n");
 exit(1);
 }
 if(getSource(G) == NIL)
 {
 return INF;
 }
 return G->distance[u];
 }
 */
int getOutDegree(Digraph G, int u){
    // Returns the number of outgoing neighbors that vertex u has in G, the number of vertices v such
    // that (u, v) is an edge in G. Returns -1 if v is not a legal vertex.
    if(u < 1 || u > G-> numVertices ){
        return -1;
    }
    //int degree = 0;
    //for(int i = 0; i< G->numVertices; i++)
    //if(G->adjacency[u][i] == [1])
    //degree++;
    //return degree;
    else{
        return length(G->adjacency[u]);
        
    }
}

List getNeighbors(Digraph G, int u){
    // Returns a list that has all the vertices that are neighbors of u. There is no input operation
    // that corresponds to getNeighbors.
    if(u < 1 || u > G->numVertices) {
        printf("Graph Error; calling getNeighbors() on NULL Graph reference\n");
    }
    
    
    
    //int num = 0;
    //for(int i = 0; i< G->adjaceny[u]; i++)
    // if( G->adjacency[u][1] == [1];
    //return (G->adjacency[v]);
    return (G->adjacency[u]);
}



int addEdge(Digraph G, int u, int v){
    // Adds v to the adjacency list of u, if that edge doesn’t already exist.
    // If the edge does already exist, does nothing. Used when edges are entered or added.
    // Returns 0 if (u, v) is a legal edge, and the edge didn’t already exist.
    // Returns 1 if (u, v) is a legal edge and the edge did already exist.
    // Returns -1 if (u, v) is not a legal edge.
    if(G == NULL) {
        printf("Graph error: calling addEdge() on NULL Graph reference\n");
        exit(1);
    }
    if(u <= 0 ||  u >G-> numVertices){
        return -1;
    }
    if(v <= 0 || v >G-> numVertices){
        return -1;
    }
    else{
        List temp = G->adjacency[u];
        Node front = getFront(temp);
        //   printf("neighbors %d", length(temp));
        //   Node back = getBack(temp);
        for(int j = 0; j < length(temp); j++) {
            //ask about this
            //  while(front == NULL)
            //front = getNextNode(front);
            
            
            if(getValue(front) == v){
            
    return 0;
            }
            
            front = getNextNode(front);
        }
        //if (u == v)
        //append(G->adjacency[u], v);
        //G->numEdges++;
        //return 0;
        
        
        append(G->adjacency[u], v);
        // append(G->adjacency[v], u);
        G->numEdges++;
     
 return 1;
        
        
    }
}

int deleteEdge(Digraph G, int u, int v) {
    // Deletes v from the adjacency list of u, if that edge exists.
    // If the edge doesn’t exist, does nothing. Used when edges are deleted.
    // Returns 0 if (u, v) is a legal edge, and the edge did already exist.
    // Returns 1 if (u, v) is a legal edge and the edge didn’t already exist.
    // Returns -1 if (u, v) is not a legal edge.
    
    if(G == NULL) {
        printf("Graph error: calling addEdge() on NULL Graph reference\n");
        exit(1);
    }
    
    if(u <= 0 ||  u >G-> numVertices){
        return -1;
    }
    if(v <= 0 || v >G-> numVertices){
        return -1;
    }
    else{
        List adj = G->adjacency[u];
        Node front = getFront(adj);
        for(int j = 0; j < length(adj); j++) {
            if(getValue(front) == v){
                deleteNode(G->adjacency[u], front);
                // deleteNode(G->adjacency[v], u);
                G->numEdges--;
                return 1;
                
            }
            front = getNextNode(front);
        }
        return 0;
        
    }
}


void unvisitAll(Digraph G){
    if(G == NULL ){
        printf("Graph error: calling unvisitAll() on NULL Graph reference/n");
        exit(1);
        for(int j = 0; j< (G->numVertices); j++){
            G->marks[j] = UNVISITED;
        }
    }
    
}

// Marks all vertices of the graph as UNVISITED.
int getMark(Digraph G, int u) {
    return (G->marks[u]);
}
// Returns the mark for vertex u, which will be UNVISITED, INPROGRESS or ALLDONE.
void setMark(Digraph G, int u, int theMark) {
    // Sets the mark for vertex u to be theMark.
    // theMark must be UNVISITED, INPROGRESS or ALLDONE.
    //if(theMark != UNVISITED || theMark != INPROGRESS || theMark != ALLDONE){
    // printf("Graph Error: calling setMark() with incorrect mark/n");
    //  exit(1);
    //
    //else
    G->marks[u] = theMark;
}
/*
 int PathExistsRecursive(Digraph G, int w, int v, int count){
 // Described below; returns FOUND or NOTFOUND, which are (different) constants.
 
 int theMark = 0;
 int theFoundValue = 1;
 setMark(G,w,INPROGRESS);
 List temp = G->adjacency[w];
 //Node back = getBack(temp);
 for(int x = 0; x< length(temp); x++){
 theMark = getMark(G,x);// FOR EACH vertex x on the getNeighbors(G,w) List
 count++;
 if (theMark == UNVISITED){
 theFoundValue = PathExistsRecursive(G,x,v, count);
 
 }
 
 
 //printf("%d", theFoundValue);
 // if (theFoundValue == FOUND){
 //  return(FOUND);
 
 //}
 }
 return count;
 // Found a path to w, so no need to continue
 // Finished processing all of x’s neighbors without finding v
 //setMark(G,w,ALLDONE);
 //return (NOTFOUND);
 
 }
 
 
 
 
 void distance(FILE* out, Digraph G, int u, int v){
 int count = 0;
 //  int theFoundValue = 0;
 int j = PathExistsRecursive(G, u, v, count);
 
 //printf("%d", j);
 //printf("%d", count);
 if(j == 0){
 fprintf(stdout, "INF");
 }
 else{
 fprintf(stdout,"%d", j);
 
 }
 }
 
 */




/*void printDigraph(FILE* out, Digraph G) {
    // Prints the Graph G in the same format as an input line, so all that a client need to do is a single
    // call to PrintGraph(). But it should not print out an edge twice. Achieve this by only printing
    // the edge for {j, k} when j < k.
    
    if(G == NULL){
        printf("Graph Error: calling printGraph() on NULL Graph reference\n");
        exit(1);
    }
    fprintf(out,"%d", G->numVertices);
    fprintf(out, ",");
    for(int j = 0; j< G-> numVertices; j++){
        
        List neighbors = G->adjacency[j];
        Node curr = getFront(neighbors);
        if(neighbors == 0 || neighbors == NULL){
            break;
        }
        //Node curr = getFront(temp);
        // while(temp != NULL)
        for(int k = 1; k<= (length(neighbors)); k++) {
            //            if(j < getValue(curr) && j>k) {
            //          break;
            //        }
            fprintf(out, " ");
            fprintf(out, "%d", j);
            fprintf(out," %d", getValue(curr));
            if(j != G->numVertices && k != (length(neighbors))){
                fprintf(stdout, ",");
            }
            
            //  if(j == getValue(curr))
            //  fprintf(stdout, " %d", j);
            //            if(j > getValue(curr))
            //              break;
        }
        //
        curr = getNextNode(curr);
        
    }
}
  */
/*void printDigraph(FILE* out, Digraph G) {
// Prints the Graph G in the same format as an input line, so all that a client need to do is a single
// call to PrintGraph(). But it should not print out an edge twice. Achieve this by only printing
// the edge for {j, k} when j < k.

if(G == NULL){
  printf("Graph Error: calling printGraph() on NULL Graph reference\n");
  exit(1);
}
int k = 0;
int j = 0;
// List front = G->adjacency[j];
//Node curr = getFront(temp);
//Node length = getBack(length);
fprintf(out,"%d", G->numVertices);
fprintf(out, ",");
for( j = 1; j<= G-> numVertices; j++){

List temp = G->adjacency[j];
Node curr = getFront(temp);
//printList(out, temp);
//return;
 if(temp == 0 || temp == NULL){
 break;
}
//Node curr = getFront(temp);
// while(temp != NULL) 
for( k = 0; k< (length(temp)); k++) {
// if (G->adjacency == 0)
// return;
// 
 

 
if(j <getValue(curr)) { 
fprintf(out, " ");
 fprintf(out, "%d", j);

//fprintf(out, " %d", j);

//  fprintf(out, "%d ", getValue(temp));
 // fprintf(stdout,"%d: ", j);
//if(k <length(temp)){


 fprintf(out," %d", getValue(curr));

//if(j + 1 == getValue(curr)){
//printf("%d", j +1);
//printf("%d", "\n hi");
//printf("%d", getValue(curr));
//if(k <= length(temp)){
fprintf(out,",");
//printf("Less than");
}

else if(j == getValue(curr) ) {
  fprintf(out, " %d", j);
  //   fprintf(out,"%d ", j);
  //  fprintf(out,",");
//printf("equal");
//}
//else if(j > getValue(curr)) {
//break;
}

curr = getNextNode(curr);

}

}
}
  */
void printDigraph(FILE* out, Digraph G) {

// Prints the Graph G in the same format as an input line, so all that a client need to do is a single

// call to PrintGraph(). But it should not print out an edge twice. Achieve this by only printing

// the edge for {j, k} when j < k.



if(G == NULL){

  printf("Graph Error: calling printGraph() on NULL Graph reference\n");

  exit(1);

}

//int* array;

int k = 0;

int j = 0;

// List front = G->adjacency[j];

//Node curr = getFront(temp);

//Node length = getBack(length);

fprintf(out,"%d", G->numVertices);

//fprintf(out, ",");

for( j = 1; j<= G-> numVertices; j++){



List temp = G->adjacency[j];

Node curr = getFront(temp);

//printList(out, temp);

//return;

 if(temp == 0 || temp == NULL){

 break;

}

for( k = 1; k<= (length(temp)); k++) {

 //int compare = getValue(curr);

//printf("%d", compare);

//printf(" ");



//printf("%d", getValue(curr));



//if(j <getValue(curr))

fprintf(out, ", ");

 fprintf(out, "%d", j);





 fprintf(out," %d", getValue(curr));

//if(j < G->numVertices &&  k<length(temp) ) {

if(j<G->numVertices){

//fprintf(out,",");

}

curr = getNextNode(curr);

//printf("%d", k);

}





}



}
void distance(FILE* out, Digraph G, int u, int v) {
    // Outputs the distance between vertices u and v if there is a directed path between them in the
    // digraph. Otherwise, outputs INF
    for(int x = 0; x< G->numVertices; x++){
        G->marks[x] = UNVISITED;
        G-> distance[x] = INF;
        G->parent[x] = NIL;
    }
    G->marks[u] = INPROGRESS;
    G->distance[u] = 0;  //INF
  G->parent[u] = NIL;          //NULL
 List L = newList();   
    append(L, u);
int count = 0;  
  while(length(L) >  0) {
        u = frontValue(L);
        List dis = G->adjacency[u];;
        Node front = getFront(dis);
      deleteFront(L);
//int count = 0;
        for(int i = 0; i <length(dis); i++){
//int count = 0;
count++;
//printf("%d", count);      
  if(G->marks[v] == UNVISITED){
G->marks[v] = INPROGRESS;
                G->distance[v] = G->distance[u] + 1;
//count++;                
G->parent[v] = u;
                append(L, v);
            }
            front = getNextNode(front);
        }
        G->marks[u] = ALLDONE;
    }
    
    
    if(G->distance[v] > 0) {
//        fprintf(out,"%d", G->distance[v]);
//count = count - 1;
fprintf(out, "%d", count);
//printf("%d", count);    
//printf("phooey");
//printf("%d blahh", count);

}

    else{
        fprintf(out, "INF");
    }
//    freeList(&L);

}
/*
int recurse(Digraph G, int w) {
   G->marks[w] = INPROGRESS;
   int z = 0;
   List recurser = G->adjacency[w];
   Node front = getFront(recurser);
   //v = getValue(front);
   for(int k = 0; k<length(recurser); k++){
         z = getValue(front);
         if(G->marks[z] == INPROGRESS){
 //          printf("NO");
           return 0;
         }
         if(G->marks[z] == UNVISITED){
            G->parent[z] = w;
            recurse(G, z);
         }
        front = getNextNode(front);

    }
    G->marks[w] = ALLDONE;
   //     printf("YES");
        return 1;



}


void topoSort(FILE* out, Digraph G){
int w = 0;
for(int k = 1; k<G->numVertices; k++){
      G->marks[k] = UNVISITED;
      G->new[k] = NIL;
}

for(int k = 1; k<G->numVertices; k++){
// printf("%d", G->marks[u]);
 if(G->marks[w] == UNVISITED){
printf("hello there");
         int f = recurse(G, w);


if(f == 0){
    printf("NO");
}
else if( f == 1){
    printf("YES");

}
}

}
}
*/

int recursive(Digraph G, int u) {
   G->marks[u] = INPROGRESS;
   int v = 0;
   List re = G->adjacency[u];
   Node front = getFront(re);
   //v = getValue(front);   
   for(int i = 0; i<length(re); i++){
         v = getValue(front);
         if(G->marks[v] == INPROGRESS){
 //          printf("NO");
//free(&temp);           
return 0;
         }	 
         if(G->marks[v] == UNVISITED){
            G->parent[v] = u;
            recursive(G, v);
         }
        front = getNextNode(front);
 
    }
    G->marks[u] = ALLDONE;
   //     printf("YES");
  // free(&temp);
     return 1;
    }

void acyclic(FILE* out, Digraph G){
//int u = 0;
//unvisitAll(G);
for(int i = 1; i<G->numVertices; i++){
     // G->marks[i] = UNVISITED;
  G->marks[i] = UNVISITED;   
 G->parent[i] = NIL;
}
int j = 0;

for(int i = 1; i<G->numVertices; i++){
// printf("%d", G->marks[u]);     
 if(G->marks[i] == UNVISITED){
//printf("djf");
          j = recursive(G, i);

}
}
if(j == 0){
    fprintf(out, "NO");
}
else if( j == 1){
    fprintf(out, "YES");

}
}


int topo(FILE* out, Digraph G, int u) {
   G->marks[u] = INPROGRESS;
   int v = 0;
   List s = G->adjacency[u];
   Node front = getFront(s);
   //v = getValue(front);   
   for(int i = 0; i<length(s); i++){
         v = getValue(front);
         if(G->marks[v] == INPROGRESS){
 //          printf("NO");
//free(&temp);           
return 0;
         }	 
         if(G->marks[v] == UNVISITED){
            G->parent[v] = u;
            topo(out, G, v);
         }
        front = getNextNode(front);
        fprintf(out, "%d", v);
fprintf(out, " ");
        deleteFront(s);
    }
    G->marks[u] = ALLDONE;
   //     printf("YES");
  // free(&temp);
append(s, v);
     return 1;
    


}



void topoSort(FILE* out, Digraph G){
//int u = 0;
//unvisitAll(G);
for(int i = 1; i<G->numVertices; i++){
     // G->marks[i] = UNVISITED;
  G->marks[i] = UNVISITED;   
 G->parent[i] = NIL;
}
int j = 0;

for(int i = 1; i<G->numVertices; i++){
// printf("%d", G->marks[u]);     
 if(G->marks[i] == UNVISITED){
//printf("djf");
          j = topo(out, G, i);

}
}
if(j == 0){
    fprintf(out, "IMPOSSIBLE");


}
}



















/*
int recursive(Digraph G, int u) {
   G->marks[u] = INPROGRESS;
   int v = 0;
   List re = G->adjacency[u];
   Node front = getFront(re);
//   v = getValue(front);   
   for(v = 0; v<length(re); v++){
      v = getValue(front);
//printf("\n");
//printf("\n");
//printf("%d", v);
//printf("%d", u);     
       // front = getNextNode(front);
 if(G->marks[v] == UNVISITED ){
printf("hi der");
printf("\n");
printf("\n");
printf("%d", v);
printf("%d", u);  
          G->parent[v] = u;
front = getNextNode(front);         
   recursive(G, v);
         } 
}
if(G->marks[v] == INPROGRESS || G->marks[v] == UNVISITED){
return 1;
}
  if(G->marks[v] == ALLDONE){
    G->marks[u] = ALLDONE;
     return 0;
    }
           

}


void acyclic(FILE* out, Digraph G){
//int u = 0;
//unvisitAll(G);
int i = 0;
for( i = 0; i<G->numVertices; i++){
     // G->marks[i] = UNVISITED;
  G->marks[i] = UNVISITED;   
 G->parent[i] = NIL;
}
int j = 0;
for( i = 0; i<G->numVertices; i++){
// printf("%d", G->marks[u]);     
 if(G->marks[i] == UNVISITED){
//printf("djf");
         j = recursive(G, i);
}
}
if(j == 0){
    fprintf(out, "NO");
}
else if( j == 1){
    fprintf(out, "YES");
}
}

*/


/*
int recurse(Digraph G, int u) {
   G->marks[u] = INPROGRESS;
   int v = 0;
   List temp = G->adjacency[u];
   Node front = getFront(temp);
   //v = getValue(front);
   for(int i = 0; i<length(temp); i++){
         v = getValue(front);
         if(G->marks[v] == INPROGRESS){
 //          printf("NO");
           return 0;
         }
         if(G->marks[v] == UNVISITED){
            G->parent[v] = u;
            recurse(G, v);
         }
        front = getNextNode(front);

    }
    G->marks[u] = ALLDONE;
   //     printf("YES");
      
  return 1;



}

void topoSort(FILE* stdout, Digraph G){
int u = 0;
for(int i = 1; i<G->numVertices; i++){
      G->marks[i] = UNVISITED;
      G->parent[i] = NIL;
}

for(int i = 1; i<G->numVertices; i++){
 printf("%d", G->marks[u]);
 if(G->marks[u] == UNVISITED){
printf("djf");
         int j = recurse(G, u);


if(j == 0){
    printf("NO");
}
else if( j == 1){
    printf("YES");

}
}
}
}

*/
/*
int topo(Digraph G, int u) {
printf("hi there");
   G->marks[u] = INPROGRESS;
//   List s = newList();
   int v = 0;
  List s = G->adjacency[u];
   Node front = getFront(s);
   //v = getValue(front);
printf("test");   
printf("%d", length(s));

for(int i = 0; i<length(s); i++){
printf("Hellodskfjskdfj");
//printf("%d", G->numVertices);         
v = getValue(front);

//printf("hi!");
         if(G->marks[v] == INPROGRESS){
 //          printf("NO");
           return 0;
         }
         if(G->marks[v] == UNVISITED){
            G->parent[v] = u;
            topo(G, v);
         
}
      
        front = getNextNode(front);
        printf("adjfkjf");
        printf("%d", v);
        deleteFront(s); 
    }
    G->marks[u] = ALLDONE;
    append(s, v);
   //     printf("YES");
      // printf("%d", printList(s));
 return 1;



}

void topoSort(FILE* stdout, Digraph G){
//printf("topo");
int i = 0;
for(int  i = 1; i < G->numVertices; i++){
      G->marks[i] = UNVISITED;
      G->parent[i] = NIL;
//printf("patrick");
}
for(i = 1; i < G->numVertices; i++){
     if(G->marks[i] == UNVISITED){
    //   printf("ruerur");
       int j = topo(G, i);
if (j == 0){
    printf("IMPOSSIBLE");
}
else if(j == 1) {
    break;
}

}
}
}
*/

/*
int topo(FILE* out, Digraph G, int u) {
printf("hi!");
   G->marks[u] = INPROGRESS;
   List s = newList();
   int v = 0;
   List temp = G->adjacency[u];
   Node front = getFront(temp);
   //v = getValue(front);
   for(int i = 0; i<G->numVertices; i++){
printf("%d", G->numVertices);         
v = getValue(front);
         if(G->marks[v] == INPROGRESS){
 //          printf("NO");
           return 0;
         }
         if(G->marks[v] == UNVISITED){
            G->new[v] = u;
            topo(out, G, v);
         
}
      
        front = getNextNode(front);
        printf("adjfkjf");
        fprintf(out,"%d", v);
        deleteFront(s); 
    }
    G->marks[u] = ALLDONE;
    append(s, v);
   //     printf("YES");
      // printf("%d", printList(s));
 return 1;



}

void topoSort(FILE* out, Digraph G){
int u = 0;
for(int i = 1; i < G->numVertices; i++){
      G->marks[i] = UNVISITED;
      G->new[i] = NIL;

}





//G->marks[u] = UNVISITED;
for(int i = 1; i < G->numVertices; i++){
//   printf("%d", G->marks[w]);
   if(G->marks[u] == UNVISITED){
       printf("ruerur");
       int j = topo(out, G, u);
if (j == 0){
    fprintf(out, "IMPOSSIBLE");
}
else if(j == 1) {
    break;
}

}
}
}
*/
/*
 // Outputs YES if the digraph is acyclic. Otherwise, outputs NO.

//Mark all vertices in the Graph as UNVISITED
for(int i = 1; i<G->numVertices; i++){
      G->marks[i] = UNVISITED;
}

//newStack(theStack) !! Makes a newStack called theStack that is empty
List s = newList();

//theStack.push(v) !! Push starting vertex onto theStack
int u = 0;
append(s, u);

//WHILE !theStack.isEmpty !! While theStack isn’t empty
while(length(s) != 0){

//theStack.pop(u) !! Pop top vertex from theStack
 u = frontValue(s);
deleteFront(s);

//IF u is UNVISITED !! Don’t do anything if u has already been visited
if(marks[u] == UNVISITED){
//Visit(u), and mark u as VISITED !! Otherwise, visit u and mark it
    G->marks[u] = INPROGRESS;
  //  G->marks[u] = ALLDONE;
//For every vertex w in neighbors(u)
List temp = G->adjacency[u];
Node front = getFront(temp);
while(front != NULL){
//for(int i = 0; i<length(temp); i++){

//theStack.push(w) !! Push u’s neighbors onto the stack
    append(s, getValue(front));
     front = getNextNode(front);
}
//!! No order is specified for neighbors
//END IF !! Added just for clarity
//END WHILE !! Added just for clarity


*/

/* //Node sFront = newNode();
 int u = 0;
 //int v = 0;
for(int i = 1; i<G->numVertices; i++){
      G->marks[i] = UNVISITED;
}
printf("Hi");
List s = newList();
append(s, u);
List temp = G->adjacency[u];
        Node front = getFront(temp);
int w = frontValue(temp);
 while(length(s) != 0 ){
  deleteFront(s);
 
 if(G->marks[u] == UNVISITED){
 G->marks[u] = INPROGRESS;
 
G->marks[u] = ALLDONE; 
for(int i = 0; i< length(temp); i++){
 append(G->adjacency[u], u);
front = getNextNode(front); 
}

 printf("YES");
}
//printf("YES");
 
 if(G->marks[u] == INPROGRESS) {
 printf("NO");
 

}
}
 }
*/


/* 
 void topoSort(FILE* out, Digraph G) {
 // Outputs a topological sort of the digraph.
 // If the digraph is not acyclic, outputs IMPOSSIBLE
 int u = 0;
 int v = 0;
int time = 0;
 for(int i = 0; i < G->numVertices; i++){
 G->marks[u] = UNVISITED;
 G->parent[u] = NIL;  //or it's G->adjacency[u] = NIL;
 }
 for(int i = 0; i < G->numVertices; i++){
 if(G->marks[u] == UNVISITED){
 visitTopo(G, u, v, time);

 }

 }
 }
  visitTopo(Digraph G, int u,int v, int time) {
 time = time + 1;
 G->distance[u] = time;
 G->marks[u] = INPROGRESS;
 List temp = G->adjacency[u];
 Node front = getFront(temp);
 for(int i = 0; i < length(temp); i++){
 if(G->marks[v] == UNVISITED) {
 G->parent[v] = u; // or it's G->adjacency[v] = u;
  getNextNode(front);      
visitTopo(G, u, v, time);
 }
 }
 G->marks[u] = ALLDONE;
 time = time + 1;
 
 }
 */
