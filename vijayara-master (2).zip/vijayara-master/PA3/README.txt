Vidya Jayaraman
vijayara
PA3
CS101

Makefile
List.c
List.h
Digraph.h
DigraphProperties.c
Makefile
README

The algorithm I attempted to use for distance was the breath-first-search procedure. I marked each of the vertices as UNVISITED. Then I use the while loop to examine each of the
vertices' adjacency lists. Then I use the for loop to iterate through the adjacency of u. Then the vertex u, becomes ALL DONE once all the vertices on u's adjacency list have been examined. I created a list, then I appended and deleted the front node. This takes O(1) time. So the total time for this is O(n) for each of the vertices. Then the sum of all the lengths of all the adjacency lists is O(m).  So, together the complexity of this algorithm is O(n+m). In order to keep track of the distance, I created a distance array that incremented the distance of the vertex v.

For acyclic, I attempted to use depth-for-search. Once again, the for loop to iterate through the number of vertices takes O(n). For DFS, the procedure is called once for each vertex. Then to go through each of adjacencies on u, it once again takes O(m) time. In order to check whether there was a cycle, I returned YES or NO depending on whether the vertex remained INPROGRESS, rather than ALLDONE in the for loop. This algorithm also took O(n+m). 


For topoSort, I also used DFS and a similar algorithm as acyclic. But instead of outputting NO, I outputted IMPOSSIBLE. And instead of outputting YES, I outputted the topological sort. To do this, I had to go through each of vertices in the graph, which took O(n) time. I created a list that was appended before the for loop that iterated through the adjacency of u. Then I printed out the front vertex of the list when it iterated through the adjacency list of u, which took O(m) time. Then I deleted the front of this list. So this algorithm also took O(n+m) time. 


While I attempted to implement each of these algorithms, I ran into issues with my code. Therefore, the outputs were rather inconsistent unfortunately. 