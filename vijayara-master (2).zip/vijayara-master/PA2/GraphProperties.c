// Vidya Jayaraman
// vijayara
// PA2
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX_LEN 160
#include "Graph.h"

void PrintGraph(FILE *out, Graph G){
    printGraph(out, G);
}
int GetOrder(Graph G){
    //printf("hi");
    return getOrder(G);
    //        int j = getOrder(G);
    //        printf( "%d", j);
}
int GetSize(Graph G){
    return getSize(G);
    
}
int GetNeighborCount(Graph G, int u){
    //        List ListTest = getNeighbors(A, 1);
    return getNeighborCount(G, u);
}


void PathExists(FILE* out, Graph G,  int u, int v){
    unvisitAll(G);
    int theFoundValue;
    theFoundValue = PathExistsRecursive(G, u, v);
    if(theFoundValue == FOUND){
        fprintf(out, "YES\n");
    }
    else{
        fprintf(out, "NO\n");
    }
}
int main(int argc, char * argv[]){
    
    FILE *in, *out;
    char line[300];
    //   Graph tokenGraph = newGraph;
    char* token;
    
    // check command line for correct number of arguments
    if( argc != 3 ){
        printf("Usage: %s <input file> <output file>\n", argv[0]);
        exit(1);
    }
    
    // open files for reading and writing
    in = fopen(argv[1], "r");
    out = fopen(argv[2], "w");
    if( in==NULL ){
        printf("Unable to open file %s for reading\n", argv[1]);
        exit(1);
    }
    if( out==NULL ){
        printf("Unable to open file %s for writing\n", argv[2]);
        exit(1);
    }
    
    
    fgets(line, 300, in);
    // printf("%s", line);
    
    const char needle[] = ",";
    const char space[] = "";
    char *ret;
    //   printf("%s", needle);
    ret = strstr(line, space);
    int x = strtol(line, &ret, 10);
    //  printf("The substring is: %s, x =%d\n", ret,x);
    int n = 0;
    int m = 0;
    //    int size = 0;
    Graph graph = newGraph(x);
    addEdge(graph, n, m);
    while( ret !=NULL) {
        //   printf("i=%d, j=%d\n",i,j);
        
        sscanf(ret, ", %d %d",&n, &m );
        //  printf("n=%d, m=%d\n",n,m);
        // size = atoi(ret);
        //              graph = newGraph(size);
        addEdge(graph, n, m);
        ret = strstr(ret+1, needle);
        
    }
    
    while(fgets(line, 300, in) != NULL) {
        
        //char new = line;
        //printf("hi");
        //       printf("%d", line);
        //char l[300];
        //char l = line;
        //printf("%s", parse):
        //printf("%s", line);
        
        //char* parse = line;
        //printf("%s", parse);
        token = strtok(line, ", \n\r");
        
        
        if ((strcmp(token, "PrintGraph")!= 0) && (strcmp(token, "GetNeighborCount")!= 0) && (strcmp(token, "GetSize")!= 0) && (strcmp(token, "GetOrder")!= 0) && (strcmp(token, "PathExists")!= 0)){
            //printf("%s", token);
            //printf("%s", "\n");
            fprintf(out, "ERROR");
            
        }
        
        
        
        
        //printf("%s", token);
        //printf("!!");
        //printf("%s", line);
        //token = strtok(l, " ");
        
        //char l = strtok(" ", "\n");
        
        
        // printf("%d", token);
        //token = strok(NULL, ",_\n");
        //  printf("%s", token);
        //compare to PrintGraph
        if(strcmp(token, "PrintGraph")== 0){
            
            //printf("\n");
            // printf("%d", size);
            //                                      printf("%s", line);
            fprintf(out, "%s", token);
            //             fprintf(out, "PrintGraph\n");
            fprintf(out, "\n");
            
            PrintGraph(out, graph);
            fprintf(out,"\n");
        }
        
        
        if(strcmp(token,"GetOrder") ==0){
            
            // printf( "GetOrder\n");
            
            fprintf(out, "%s", token);
            fprintf(out, "\n");
            GetOrder(graph);
            int j = getOrder(graph);
            fprintf(out, "%d", j);
            fprintf(out, "\n");
        }
        if(strcmp(token, "GetSize") == 0){
            fprintf(out, "%s", token);
            
            GetSize(graph);
            fprintf(out, "\n");
            int s = getSize(graph);
            fprintf(out,"%d",s);
            fprintf(out, "\n");
        }
        
        //printf("%s", line);
        //printf("%s", token);
        if(strcmp(token, "GetNeighborCount") == 0){
            fprintf(out,"%s", token);
            //fprintf(out, "\n");
            //    printf("%s", parsing);
            //    printf("\n");
            token = strtok(NULL, "\n\r");
            //        printf("%s", token);
            if(token != NULL) {
                
                //    if(sscanf(token,"%s %d","GetNeighborCount",r)) {
                
                //  }
                //                         printf("GetNeighborCount");
                fprintf(out, "%s"," ");
                fprintf(out, "%s", token);
                //printf("%s", " ");
                fprintf(out, "\n");
                GetNeighborCount(graph, m);
                //List ListTest = getNeighbors(graph, m);
                //printList(stdout, ListTest);//printf("\n");
                int tester = getNeighborCount(graph, m);
                tester = GetNeighborCount(graph, m);
                fprintf(out,"%d", tester);
                fprintf(out, "\n");
                //break;
                
            }
            else{
                printf("ERROR");
            }
        }
        
        if(strcmp(token, "PathExists") == 0){
            
            fprintf(out, "%s", token);
            char* new = 0;
            token = strtok(NULL, " ");
            fprintf(out, "%s", " ");
            fprintf(out, "%s", token);
            fprintf(out, "%s", " ");
            new = token;
            new = strtok(NULL, "\n\r");
            fprintf(out, "%s",new);
            
            if(token != NULL && new != NULL) {
                //    if(sscanf(token, "%s %s %s", "PathExists", token, new)){
                
                //     }
                //      token = strtok(NULL, "\n ");
                fprintf(out, "%s", "\n");
                PathExists(out,graph, n, m);
            }
            else{
                printf("ERROR");
            }
            
            
        }
       
        
    }
    /*else  if ((strcmp(token, "PrintGraph")!= 0) && (strcmp(token, "GetNeighborCount")!= 0) && (strcmp(token, "GetSize")!= 0) && (strcmp(token, "GetOrder")!= 0) && (strcmp(token, "PathExists")!= 0)){
     printf("%s", token);
     printf("%s", "\n");
     fprintf(out, "ERROR");
     
     }
     
     }*/
    
    
    
freeGraph(&graph);    
    
    
    //         close files
    fclose(in);
    fclose(out);
    
    return(0);
}
