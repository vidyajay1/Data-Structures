// Vidya Jayaraman 
// vijayara
// PA2
# include <stdio.h>
# include <stdlib.h>
# include "Graph.h"

struct GraphObj {
  List *adjacency; //array of List: contains neighbors for a particular vertex 
             //(depending on the jth element  
  int numVertices; //number of vertices in Graph
  int numEdges; //number of edges in graph (size of graph)
  int *marks; //UNVISITED, INPROGRESS, ALLDONE
}
GraphObj; 


// Returns a Graph that points to a newly created GraphObj representing a graph which has
// n vertices and no edges.


Graph newGraph(int numVertices){
//  Graph graph = malloc(sizeof(struct GraphObj));
const size_t size = sizeof(struct GraphObj);
Graph graph = (struct GraphObj*) malloc(size);  
graph->marks = malloc(sizeof(int)* (numVertices +1));
  graph->adjacency = malloc(sizeof(List)*(numVertices + 1));



//  graph->adjacency = calloc(n+1, sizeof(List));
//graph->marks = calloc(n+1, sizeof(int));
  graph->numVertices = numVertices;
  graph->numEdges = 0;
int j;
for(j = 0; j<(numVertices+1); j++) {
  graph->adjacency[j] = newList();
  graph->marks[j] = 2; //2 for unvisited 
}
return graph;
}



// Frees all dynamic memory associated with its Graph* argument, and sets
// *pG to NULL.


void freeGraph(Graph *pG) {
  Graph graph = *pG; 

if(pG != NULL && *pG != NULL){
int j = 0;

//printf("Hi");
 for(j = 0; j< getOrder(graph); j++){
  // printf("%d\n", length(graph->adjacency[j]));
//   free(graph->adjacency[j]);
    
   freeList(&(*pG)->adjacency[j]);
  // free((graph)->adjacency[j]);
  // free(&(graph)->marks[j]);
}
free(graph->adjacency);
free(graph->marks);
graph->adjacency = NULL;
graph->marks = NULL;
free(graph);
*pG = NULL;
pG = NULL;
}
}

// Returns the order of G, the number of vertices in G.
int getOrder(Graph G){
  if(G == NULL){
    printf("Graph Error: calling getOrder() on NULL Graph reference\n");
    exit(1);
  }
 // fprintf(out,"%d", G->numVertices);
  return G->numVertices;
//  printf("%d",G->numVertices);
    
}


int getSize(Graph G){
// Returns the size of G, the number of edges in G.
  if(G == NULL){
    printf("Graph Error: calling getSize() on NULL Graph reference\n");
    exit(1);
}
return G->numEdges;
}


int getNeighborCount(Graph G, int v) {
// Returns the number of neighbors that vertex v has in G. Returns -1 if v is not a legal vertex
if(v < 1 || v > G-> numVertices ){
 return -1;
} 
else{


return length(G->adjacency[v]);
}
}


List getNeighbors(Graph G, int v){
// Returns a list that has all the vertices that are neighbors of u. There is no input operation
// that corresponds to getNeighbors.
if(v < 1 || v > G->numVertices) {
printf("Graph Error; calling getNeighbors() on NULL Graph reference\n");
}
return (G->adjacency[v]);
}



int addEdge(Graph G, int u, int v){
// Adds v to the adjacency list of u and u to the adjacency list of v, if that edge doesn’t
// already exist. If the edge does already exist, does nothing. Used when edges are entered.
// Returns 0 if u and v are legal vertices, otherwise returns -1.
if(G == NULL) {
  printf("Graph error: calling addEdge() on NULL Graph reference\n");
  exit(1);
}

 if(u <= 0 ||  u >G-> numVertices){ 
 return -1;
}
if(v <= 0 || v >G-> numVertices){  
 return -1;
}
else{
   List temp = G->adjacency[u];
   Node front = getFront(temp);
//   printf("neighbors %d", length(temp));
//   Node back = getBack(temp);
   for(int j = 0; j < length(temp); j++) {
//ask about this    
//  while(front == NULL)
 //front = getNextNode(front);


  if(getValue(front) == v){
  return 0;
  
 }

  front = getNextNode(front);  
}
if (u == v){
append(G->adjacency[u], v);
G->numEdges++;
return 0;
}
else{
  append(G->adjacency[u], v);
  append(G->adjacency[v], u);
  G->numEdges++;
  return 0;

}
}
}
void unvisitAll(Graph G){
if(G == NULL ){
 printf("Graph error: calling unvisitAll() on NULL Graph reference/n");
 exit(1);
for(int j = 1; j<= G->numVertices; j++){ 
G->marks[j] = UNVISITED;
}
}

}  
// Marks all vertices of the graph as UNVISITED.
int getMark(Graph G, int u) {
 return (G->marks[u]);
}
// Returns the mark for vertex u, which will be UNVISITED, INPROGRESS or ALLDONE.
void setMark(Graph G, int u, int theMark) {
// Sets the mark for vertex u to be theMark.
// theMark must be UNVISITED, INPROGRESS or ALLDONE.
//if(theMark != UNVISITED || theMark != INPROGRESS || theMark != ALLDONE){
 // printf("Graph Error: calling setMark() with incorrect mark/n");
//  exit(1);
//}
//else{
G->marks[u] = theMark;

//}
}

int PathExistsRecursive(Graph G, int w, int v){
// Described below; returns FOUND or NOTFOUND, which are (different) constants.
if ( w == v){ 
   return (FOUND);
}
int theMark = 0; 
int theFoundValue = 0;
setMark(G,w,INPROGRESS);
// List temp = G->adjacency[w];
//Node back = getBack(temp);
for(int x = 0; x< G->numVertices; x++){
  theMark = getMark(G,x);// FOR EACH vertex x on the getNeighbors(G,w) List
  if (theMark == UNVISITED){
     theFoundValue = PathExistsRecursive(G,x,v);
}
  if (theFoundValue == FOUND){
     return(FOUND);
}
}

// Found a path to w, so no need to continue
// Finished processing all of x’s neighbors without finding v
setMark(G,w,ALLDONE);
return (NOTFOUND);
}








void printGraph(FILE* out, Graph G) {
// Prints the Graph G in the same format as an input line, so all that a client need to do is a single
// call to PrintGraph(). But it should not print out an edge twice. Achieve this by only printing
// the edge for {j, k} when j < k.

if(G == NULL){
  printf("Graph Error: calling printGraph() on NULL Graph reference\n");
  exit(1);
}
int k = 0;
int j = 0;
// List front = G->adjacency[j];
//Node curr = getFront(temp);
//Node length = getBack(length);
fprintf(out,"%d", G->numVertices);
fprintf(out, ",");
for( j = 1; j<= G-> numVertices; j++){

List temp = G->adjacency[j];
Node curr = getFront(temp);
//printList(out, temp);
//return;
 if(temp == 0 || temp == NULL){
 break;
}
//Node curr = getFront(temp);
// while(temp != NULL) 
for( k = 0; k< (length(temp)); k++) {
// if (G->adjacency == 0)
// return;
// 
 

 
if(j <getValue(curr)) { 
fprintf(out, " ");
 fprintf(out, "%d", j);

//fprintf(out, " %d", j);

//  fprintf(out, "%d ", getValue(temp));
 // fprintf(stdout,"%d: ", j);
//if(k <length(temp)){


 fprintf(out," %d", getValue(curr));

//if(j + 1 == getValue(curr)){
//printf("%d", j +1);
//printf("%d", "\n hi");
//printf("%d", getValue(curr));
//if(k <= length(temp)){
fprintf(out,",");
//printf("Less than");
}

else if(j == getValue(curr) ) {
  fprintf(out, " %d", j);
  //   fprintf(out,"%d ", j);
  //  fprintf(out,",");
//printf("equal");
//}
//else if(j > getValue(curr)) {
//break;
}

curr = getNextNode(curr);

}

}
}

